
	<!-- Footer -->
	<div id="footer">
			<ul class="menus">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widgets') ) : ?>  
     			<?php endif; ?> 
	</div>
	<!-- END footer -->
	<!-- Copyright -->
	<div id="copyright">
				<a href="http://www.webtegrity.com">Webtegrity &copy; 2013 | All Right Reserved</a>
			</div>
			<!-- END copyright -->
	</div>
<!-- End Wrapper -->
</body>
</html>