<!doctype html>
<html>
<head>
<link href='http://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link href="<?php bloginfo('stylesheet_url');?>" rel="stylesheet" media="screen">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
</head>
<body>
<!-- Wrapper -->
<div id="wrapper" class="shadow">
<!-- Header -->
<div id="header">
<!-- Logo -->
<div class="logo">
<a href="http://localhost:8888" class="image_link"><img src="<?php bloginfo('template_directory'); ?>/images/legends_logo.jpg" alt="Legends Pharmacy"></a>
</div>
<!-- END Logo -->

<!-- Navigation -->
<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>
<!-- END Navigation-->
</div>
<!-- END Header -->