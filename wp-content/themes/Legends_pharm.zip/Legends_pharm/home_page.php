<?php
/*
Template Name: Home Page
*/
?>

<?php get_header();?>
<div id="content">
<!-- Only displays on the Homepage -->
<?php if(is_front_page()){?>

<!-- Slider shows only on front page -->
	
		<div id="slider">
			<?php putRevSlider("slider1")?>
		</div>
		
	<!-- Slider END -->
	
	
	<!-- Home center 3 column content portion -->
	<div class="threeColumn">
		<div class="left">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Middle Left') ) : ?>  
      	<?php endif; ?> 
      	</div>
      	
      	<div class="left">
      	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Middle Center') ) : ?>  
      	<?php endif; ?> 
      	</div>
      	
      	<div class="left">
      	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Middle Right') ) : ?>  
      	<?php endif; ?>
      	</div> 
      	<div class="clear"></div>
      </div>
	
	<!-- Home Center END -->
	
	<!-- Google Maps and Testimonail widgets-->
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Google Map Widget') ) : ?>  
      	<?php endif; ?>  
      
      <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Testimonial Widget') ) : ?>  
      <?php endif; ?>  
      <div class="clear"></div>
    <!--  Google MAps and Testimonials END -->  
    
    <!-- Home END -->
<?php } ?>
<?php get_footer();?>