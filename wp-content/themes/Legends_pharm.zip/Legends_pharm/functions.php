<?php
function register_my_menu() {
	register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_my_menu' );


add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);
function special_nav_class($classes, $item){
	if( in_array('current-menu-item', $classes) ){
		$classes[] = 'active ';
	}
	return $classes;
}


if (function_exists('register_sidebar')) {
	register_sidebar(array(
	'name' => 'Footer Widgets',
	'id'   => 'Footer Widgets',
	'description'   => '4 Column on footer',
	'before_widget' => '<li><ul class="footer-menu">',
	'after_widget'  => '</ul></li>',
	'before_title'  => '<li><h1>',	
	'after_title'   => '</h1></li>'
			));

	register_sidebar(array(
	'name' => 'Google Map Widget',
	'id'   => 'Google Map Widget',
	'description'   => 'Frontpage Google Map Holder',
	'before_widget' => '<div class="google_map">',
	'after_widget'  => '</div>',
	'before_title'  => '<h1>',
	'after_title'   => '</h1>'
			));
	register_sidebar(array(
	'name' => 'Testimonial Widget',
	'id'   => 'Testimonial Widget',
	'description'   => 'Frontpage Testimonial Holder',
	'before_widget' => '<div class="testimonial">',
	'after_widget'  => '</div>',
	'before_title'  => '<h1>',
	'after_title'   => '</h1>'
			));
	register_sidebar(array(
	'name' => 'Home Middle Left',
	'id'   => 'Home Middle Left',
	'description'   => 'Left portion of the home 3 column content',
	'before_widget' => '',
	'after_widget'  => '',
	'before_title'  => '<h1>',
	'after_title'   => '</h1>'
			));
	register_sidebar(array(
	'name' => 'Home Middle Center',
	'id'   => 'Home Middle Center',
	'description'   => 'Center portion of the home 3 column content',
	'before_widget' => '',
	'after_widget'  => '',
	'before_title'  => '<h1>',
	'after_title'   => '</h1>'
			));
	register_sidebar(array(
	'name' => 'Home Middle Right',
	'id'   => 'Home Middle Right',
	'description'   => 'Right portion of the home 3 column content',
	'before_widget' => '',
	'after_widget'  => '',
	'before_title'  => '<h1>',
	'after_title'   => '</h1>'
			));
	register_sidebar(array(
	'name' => 'Sidebar',
	'id'   => 'Sidebar',
	'description'   => 'Right sidebar',
	'before_widget' => '',
	'after_widget'  => '',
	'before_title'  => '<h1>',
	'after_title'   => '</h1>'
			));
}


?>
