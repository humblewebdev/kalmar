<?php get_header();?>



<!-- How do you want to approach sub-menu? -->

<div id="content">
<!-- Only displays on the Homepage -->
<?php if(is_front_page()){?>

<!-- Slider shows only on front page -->
	
		<div id="slider">
			<?php putRevSlider("slider1")?>
		</div>
		
	<!-- Slider END -->
	
	
	<!-- Home center 3 column content portion -->
	<div class="threeColumn">
		<div class="left">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Middle Left') ) : ?>  
      	<?php endif; ?> 
      	</div>
      	
      	<div class="left">
      	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Middle Center') ) : ?>  
      	<?php endif; ?> 
      	</div>
      	
      	<div class="left">
      	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Middle Right') ) : ?>  
      	<?php endif; ?>
      	</div> 
      	<div class="clear"></div>
      </div>
	
	<!-- Home Center END -->
	
	<!-- Google Maps and Testimonail widgets-->
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Google Map Widget') ) : ?>  
      	<?php endif; ?>  
      
      <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Testimonial Widget') ) : ?>  
      <?php endif; ?>  
      <div class="clear"></div>
    <!--  Google MAps and Testimonials END -->  
    
    <!-- Home END -->
<?php } else {?>
	
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h1 class="page_header"><?php the_title(); ?></h1>
<div id="content_sidebar">
<p><?php the_content(__('(more...)')); ?></p> 
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
	</div>
	
	<div id="sidebar">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>  
      <?php endif; ?>
	</div>
	
	<div class="clear"></div>
<?php } ?>
</div>



<?php get_footer()?>			