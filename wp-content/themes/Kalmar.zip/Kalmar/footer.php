<div class="wrapper">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Left Footer Widgets') ) : ?>  
     			<?php endif; ?>
     		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Center Footer Widgets') ) : ?>  
     			<?php endif; ?> 
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Right Footer Widgets') ) : ?>  
     			<?php endif; ?>	
     			<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
     				<img src="">
     			</div>
		</div>
	</footer>
	<div class="copyright-area">
		<div class="wrapper">
			Kalmar rt center 103 guadalupe dr. cibolo tx 78108 
		</div>
	</div>

	
	<script>window.jQuery || document.write('<script src="<?php echo get_template_directory_uri(); ?>js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/plugins.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/main.js"></script>

</body>
</html>