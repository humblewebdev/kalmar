<?php
require_once(get_theme_root().'/Kalmar/plugins/classes/Product.class.php');
require_once(get_theme_root().'/Kalmar/plugins/classes/formValidator.class.php');

?>