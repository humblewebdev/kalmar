<h1>
	<ul>
		<li>Add Instructions</li>
	</ul>
</h1>
	<style>
		#wp-featureContent-wrap {
			width: 1000px;
		}
		textarea {
			resize: vertical;
		}

		.wrapper {
			width: 100%;
			padding: 0 20px;
		}

		#featureContent {
			height: 100px;
		}
	</style>


	<div class="wrapper">
	<h1>Military Landing Page</h1>
		<div class="well">
			<div class="form-group">
					<label for="mil_page_image">Military Page Image</label> <input
						type="file" class="form-control" name="mil_page_image"
						id="mil_page_image" placeholder="Military Page Image">
			</div>
			<div class="form-group">
					<label for="mil_page_text">Military Page Text</label> 
						<?php wp_editor($content, 'mil_page_text'); ?>
			</div>
		</div>
	</div>

