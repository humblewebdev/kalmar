<?php
class Feature() {
	function addFeature($features ) {
		try{
			global $wpdb;
			$wpdb->insert ( 'wp_dummy_sitemil_specs', $features );
		}
		
		
	}
	function deleteFeature() {
	}
	function editFeature() {
	}
}
?>