<?php
class product {
	public static function addProduct($productName, $productImage, $productDescription, $isMil) {
		/* ##### Checking to see if name already exists ##### */
		$table = ($isMil ? 'wp_dummy_sitemil_product' : 'wp_dummy_sitecomm_product');
		$item = ($isMil ? 'mil_product_name' : 'comm_product_name');
		global $wpdb;
		$myrows = $wpdb->get_results ( "SELECT $item from  $table where username = $productName" );
		var_dump($myrows);
		if (!empty($myrows)) {
			return (- 1);
		} else {
			try {
				$name = $productName;
				$image = $productImage;
				$description = $productDescription;
				$wpdb->insert ( 'wp_dummy_sitemil_product', array (
						'mil_product_name' => $productName,
						'mil_product_image' => $productImage,
						'mil_product_desc' => $productDescription 
				) );
			} catch ( Exception $e ) {
				
				$fh = fopen ( get_theme_root () . '/Kalmar/plugins/errorlog.txt', 'a+' );
				
				$error = <<<EOL

timeStamp: {time()}
Message: {$e->getMessage()}
Code: {$e->getCode()}
File: {$e->getFile()}
Line: {$e->getLine()}

EOL;
				
				fwrite ( $fh, $error ); // write to txtfile
				
				fclose ( $fh );
				
				return (- 1);
			}
		}
	}
	public static function deleteProduct($productID) {
		return boolean;
	}
	public static function editProduct($productID, $productName, $productImage, $productDescription) {
		return boolean;
	}
}
?>