<style>
#wp-featureContent-wrap {
width: 1000px;
}
textarea {
	resize: vertical;
}

.wrapper {
	width: 100%;
	padding: 0 20px;
}

#featureContent {
	height: 100px;
}
</style>

<script>
$(document).ready(function(){
				
});
</script>

<div class="wrapper">
	<h1>Military Products </h1>
	<div class="table-responsive panel panel-default">
		<table class="table table-striped">
			<tbody>
				<tr>
					<td>Image</td>
					<td>Name</td>
					<td>Description</td>
					<td>Options</td>
				</tr>
				<tr>
					<td>Image</td>
					<td>RT240</td>
					<td></td>
					<td><button class="btn btn-primary">
							<span class="glyphicon glyphicon-cog"></span> edit
						</button>
						<button class="btn btn-danger">
							<span class="glyphicon glyphicon-minus-sign"></span> Delete
						</button></td>
				</tr>
				<tr>
					<td>Image</td>
					<td>RT022</td>
					<td></td>
					<td><button class="btn btn-primary">
							<span class="glyphicon glyphicon-cog"></span> edit
						</button>
						<button class="btn btn-danger">
							<span class="glyphicon glyphicon-minus-sign"></span> Delete
						</button></td>
				</tr>
			</tbody>
		</table>
	</div>



	<ul class="nav nav-tabs">
		<li class="active"><a href="#home" data-toggle="tab">Product</a></li>
		<li><a href="#features" data-toggle="tab">Features</a></li>
		<li><a href="#specifications" data-toggle="tab">Specifications</a></li>
		<li><a href="#gallery" data-toggle="tab">Gallery</a></li>
	</ul>
	<div id="error"></div>
	
	<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>"
		enctype="multipart/form-data">
		<div class="tab-content">

			<!--
			Home Panel
			############################################################
			-->
			<div class="tab-pane well active" id="home">
				
				<!--<div class="alert alert-danger" id="productError"></div>-->
				
				<div class="form-group">
					<label for="mil_product_name">Product Name</label> <input
						type="text" class="form-control" name="mil_product_name"
						id="mil_product_name" placeholder="Product Name">
				</div>

				<div class="form-group">
					<label for="mil_product_image">Product Image (Max Size: 3MB  Allowable filetypes:  jpg, jpeg, png, gif)</label><br> <input
						type="file" name="mil_product_image" id="mil_product_image"
						class="form-control">
				</div>

				<div class="form-group">
					<label for="mil_product_desc">Product Description</label>
		    				<?php wp_editor($content, 'mil_product_desc'); ?>
				</div>


			</div>

			<!-- 
					Features Panel
					############################################################
					-->
			<div class="tab-pane well" id="features">
					<div id="features_content">
					
					</div>
				
				<a href="#" class="btn btn-success" id="addFeature">Add Feature</a>
				
				<script>
				$("#features").ready(function() {
					var addDiv = $('#features_content');
					var i = $('#features form-inline').size();
					console.log(i);
			
					$('#addFeature').on('click', function(){
						if(i<=50){
							$('<div class="form-inline"><div class="form-group"><label for="featureTitle">Feature Title</label> <input type="text" class="form-control" name="mil_feature_Title[]" id="featureTitle" placeholder="Feature Title"></div><div class="form-group"><label for="featureImage">Feature Image</label> <input type="file" class="form-control" id="featureImage" name="mil_feature_image[]" placeholder="Feature Image"></div><div class="form-group"><label for="bullets">Feature bullet points</label><textarea id="bullets" class="form-control" name="mil_feature_bullets[]" cols="100" placeholder="place each bullet on a new line"></textarea></div></div>').appendTo(addDiv);
							i++;
							return false;
						} else {
							var error = $('#error');
							$('<div class="alert alert-danger">Maximum allowable input fields met.</div>').appendTo(error);
							$("#error").show().delay(5000).fadeOut();
						}
					});
				});
				</script>
			</div>
			<!-- 
					Specifications Panel
					############################################################
					-->
			<div class="tab-pane well" id="specifications">
				<h3>Instructions!!! Instriuctions!!! Instructions!!!</h3>
				<Br>
				<h2>Engine</h2>
				<div class="form-inline">
					<!-- #####Engine Make##### -->
					<div class="form-group">
						<label for="mil_engine_make">Make</label> <input type="text"
							class="form-control" name="mil_engine_make" id="mil_engine_make" placeholder="Engine Make">
					</div>
					<!-- #####Engine Model##### -->
					<div class="form-group">
						<label for="mil_engine_model">Model</label> <input type="text"
							class="form-control" name="mil_engine_model" id="mil_engine_model" placeholder="Engine Model">
					</div>
					<!-- #####Engine Cylinders##### -->
					<div class="form-group">
						<label for="mil_engine_cylinders">Cylinders</label> <input type="text"
							class="form-control" name="mil_engine_cylinders" id="mil_engine_cylinders"
							placeholder="Engine Cylinders">
					</div>
					<!-- #####Engine Power##### -->
					<div class="form-group">
						<label for="mil_engine_power">Power</label> <input type="text"
							class="form-control" name="mil_engine_power" id="enginePower" placeholder="Engine Power">
					</div>
					<!-- #####Engine Displacement##### -->
					<div class="form-group">
						<label for="mil_engine_displacement">Displacement</label> <input
							type="text" class="form-control" name="mil_engine_displacement" id="mil_engine_displacement"
							placeholder="Engine Displacement">
					</div>
					<!-- #####Engine Cooling##### -->
					<div class="form-group">
						<label for="mil_engine_cooling">Cooling</label> <input type="text"
							class="form-control" name="mil_engine_cooling" id="mil_engine_cooling"
							placeholder="Engine Cooling">
					</div>
					<!-- #####Engine Fuel##### -->
					<div class="form-group">
						<label for="mil_engine_fuel">Fuel</label> <input type="text"
							class="form-control" name="mil_engine_fuel" id="mil_engine_fuel" placeholder="Engine Fuel">
					</div>
				</div>

				<h2>Performance</h2>
				<div class="form-inline">
					<!-- #####Performance Travel Speed Unladen##### -->
					<div class="form-group">
						<label for="mil_performance_speedUnladen">Travel Speed, Unladen</label>
						<input type="text" class="form-control"
							name="mil_performance_speedLaden" id="mil_performance_speedUnladen" placeholder="Travel Speed, Unladen">
					</div>
					<!-- #####Performance Travel Speed Laden##### -->
					<div class="form-group">
						<label for="mil_performance_speedLaden">Travel Speed, Laden</label> <input
							type="text" class="form-control" name="mil_performance_speedLaden" id="mil_performance_speedLaden"
							placeholder="Travel Speed, Laden">
					</div>
					<!-- #####Performance Travel Speed Reverse##### -->
					<div class="form-group">
						<label for="mil_performance_speedReverse">Travel Speed, Reverse</label>
						<input type="text" class="form-control"
							name="mil_performance_speedReverse" id="mil_performance_speedReverse" placeholder="Travel Speed, Reverse">
					</div>
					<!-- #####Performance Gradeability##### -->
					<div class="form-group">
						<label for="mil_performance_gradeability">Gradeablity</label> <input
							type="text" class="form-control" name="mil_performance_gradeability" id="mil_performance_gradeability"
							placeholder="Gradeability">
					</div>
					<!-- #####Performance Unladen##### -->
					<div class="form-group">
						<label for="mil_performance_unladen">Unladen</label> <input type="text"
							class="form-control" name="mil_performance_unladen" id="mil_performance_unladen"
							placeholder="Unladen">
					</div>
					<!-- #####Performance Laden##### -->
					<div class="form-group">
						<label for="mil_performance_laden">Laden</label> <input type="text"
							class="form-control" name="mil_performance_laden" id="mil_performance_laden" placeholder="Laden">
					</div>
					<!-- #####Performance Fording Depth##### -->
					<div class="form-group">
						<label for="mil_performance_fordingDepth">Fording Depth</label> <input
							type="text" class="form-control" name="mil_performance_fordingDepth" id="mil_performance_fordingDepth"
							placeholder="Fording Depth">
					</div>
				</div>

				<h2>Transmission</h2>
				<div class="form-inline">
					<!-- #####Transmission Make##### -->
					<div class="form-group">
						<label for="mil_transmission_make">Transmission Make</label> <input
							type="text" class="form-control" name="mil_transmission_make" id="mil_transmission_make"
							placeholder="Transmission Make">
					</div>
					<!-- #####Transmission Model##### -->
					<div class="form-group">
						<label for="mil_transmission_model">Transmission Model</label> <input
							type="text" class="form-control" name="mil_transmission_model" id="mil_transmission_model"
							placeholder="Transmission Model">
					</div>
					<!-- #####Transmission Type##### -->
					<div class="form-group">
						<label for="mil_transmission_type">Transmission Type</label> <input
							type="text" class="form-control" name="mil_transmission_type" id="mil_tranmission_type"
							placeholder="Transmission Type">
					</div>
					<!-- #####Transmission Gears##### -->
					<div class="form-group">
						<label for="mil_transmission_gears">Transmission Gears</label> <input
							type="text" class="form-control" name="mil_transmission_gears" id="mil_transmission_gears"
							placeholder="Transmission Gears">
					</div>
				</div>

				<h2>Weight</h2>
				<div class="form-inline">
					<!-- #####Weight Curb Weight##### -->
					<div class="form-group">
						<label for="mil_weight_curb">Curb Weight</label> <input type="text"
							class="form-control" name="mil_weight_curb" id="mil_weight_curb" placeholder="Curb Weight">
					</div>
					<!-- #####Weight Front Axel##### -->
					<div class="form-group">
						<label for="mil_weight_frontAxelWeight">Front Axel Weight</label> <input
							type="text" class="form-control" name="mil_weight_frontAxelWeight" id="mil_weight_frontAxelWeight"
							placeholder="Front Axel Weight">
					</div>
					<!-- #####Weight Rear Axel##### -->
					<div class="form-group">
						<label for="mil_weight_rearAxelWeight">Rear Axel Weight</label> <input
							type="text" class="form-control" name="mil_weight_rearAxelWeight" id="mil_weight_rearAxelWeight"
							placeholder="Rear Axel Weight">
					</div>
				</div>


				<h2>Axels</h2>
				<div class="form-inline">
					<!-- #####Axels Make##### -->
					<div class="form-group">
						<label for="mil_axel_make">Axels Make</label> <input type="text"
							class="form-control" name="mil_axel_make" id="mil_axel_make" placeholder="Axels Make">
					</div>
					<!-- #####Axels Front Model##### -->
					<div class="form-group">
						<label for="mil_axel_frontModel">Front Axel Model</label> <input
							type="text" class="form-control" name="mil_axel_frontModel" id="mil_axel_frontModel"
							placeholder="Front Axel Model">
					</div>
					<!-- #####Axels Rear Model##### -->
					<div class="form-group">
						<label for="mil_axel_rearModel">Rear Axel Model</label> <input type="text"
							class="form-control" name="mil_axel_rearModel" id="mil_axel_rearModel" placeholder="Rear Axel Model">
					</div>
				</div>

				<h2>Service Capacity</h2>
				<div class="form-inline">
					<!-- #####Service Capacities Fuel##### -->
					<div class="form-group">
						<label for="mil_service_fuel">Fuel Tank</label> <input type="text"
							class="form-control" name="mil_service_fuel" id="mil_service_fuel" placeholder="Fuel Tank">
					</div>
					<!-- #####Service Capacities Hydraulic##### -->
					<div class="form-group">
						<label for="mil_service_hydraulic">Hydraulic Tank</label> <input
							type="text" class="form-control" name="mil_service_hydraulic" id="mil_service_hydraulic"
							placeholder="Hydraulic Tank">
					</div>
				</div>


				<h2>Tires</h2>
				<div class="form-inline">
					<!-- #####Tire size##### -->
					<div class="form-group">
						<label for="mil_tire_size">Tire Size</label> <input type="text"
							class="form-control" name="mil_tire_size" id="mil_tire_size" placeholder="Tire Size">
					</div>
				</div>



				<h2>Brakes</h2>
				<div class="form-inline">
					<!-- #####Brakes Service##### -->
					<div class="form-group">
						<label for="mil_brake_service">Service</label> <input type="text"
							class="form-control" name="mil_brake_service" id="mil_brake_service" placeholder="Service">
					</div>
					<!-- #####Brakes Parking##### -->
					<div class="form-group">
						<label for="mil_brake_parking">Parking</label> <input type="text"
							class="form-control" name="mil_brake_parking" id="mil_brake_parking"
							placeholder="Hydraulic Tank">
					</div>
				</div>


				<h2>Additional Data</h2>
				<div class="form-inline">
					<!-- #####Additional Data Electrical System##### -->
					<div class="form-group">
						<label for="mil_electrical_system">Electrical System</label> <input
							type="text" class="form-control" name="mil_electrical_system" id="mil_electrical_system"
							placeholder="Electrical System">
					</div>
					<!-- #####Additional Data Alternator##### -->
					<div class="form-group">
						<label for="mil_alternator">Alternator</label> <input type="text"
							class="form-control" id="mil_alternator" name="mil_alternator" placeholder="Alternator">
					</div>
				</div>

				<h2>Specs Sheet</h2>
				<div class="form-inline">
					<!-- #####Specs Sheet Upload##### -->
					<div class="form-group">
						<label for="mil_spec_sheet">Specifications Sheet</label> <input
							type="file" class="form-control" name="mil_spec_sheet" id="mil_spec_sheet"
							placeholder="Service">
					</div>
				</div>



			</div>
			<!--
					Gallery Panel
					############################################################
					-->
			<div class="tab-pane well" id="gallery">
				<script>
					$(document).ready(function(){
						var addDiv = $('#addinput');
						var i = $('#addinput .input-group').size();
			
						$('#addImage').on('click', function(){
							if(i<=50){
								$('<div class="gallery_element"><label for="gallery_image_'+ i +'">Add An Image</label><div class="input-group"><input type="file" class="form-control" id="gallery_image_'+ i +'" size="40" name="gallery_image_'+ i +'" value="" placeholder="Upload An Image for Your Gallery"><a href="#" class="input-group-btn removeImage btn btn-danger"><span class="glyphicon glyphicon-minus"></span></a></div></div>').appendTo(addDiv);
								i++;
								return false;
							} else {
								var error = $('#error');
								$('<div class="alert alert-danger">Maximum allowable input fields met.</div>').appendTo(error);
								$("#error").show().delay(5000).fadeOut();
							}
						});

						$('#addVideo').on('click', function(){
							if(i<=50){
								$('<div class="gallery_element"><label for="gallery_video_'+ i +'">Add A YouTube Video</label><div class="input-group"><input type="text" class="form-control" id="gallery_video_'+ i +'" size="40" name="gallery_video_'+ i +'" value="" placeholder="Paste Your YouTube Embed code here"><a href="#" class="input-group-btn removeImage btn btn-danger"><span class="glyphicon glyphicon-minus"></span></a></div></div>').appendTo(addDiv);
								i++;
								return false;
							} else {
								var error = $('#error');
								$('<div class="alert alert-danger">Maximum allowable input fields met.</div>').appendTo(error);
								$("#error").show().delay(5000).fadeOut();
							}
						});
						
						$(document).on('click','.removeImage', function(){
									var paragraph = $(this).parents('.gallery_element').remove();
									i--;
						});
					});
				</script>

				<a href="#" id="addImage" class="btn btn-success"> <span
					class="glyphicon glyphicon-camera"></span> Add Image
				</a> <a href="#" id="addVideo" class="btn btn-success"> <span
					class="glyphicon glyphicon-film"></span> Add YouTube Video
				</a>
				<div id="addinput"></div>
			</div>
		</div>
		<input class="btn btn-primary" type="submit"
			value="Add Military Product" />
	</form>
	