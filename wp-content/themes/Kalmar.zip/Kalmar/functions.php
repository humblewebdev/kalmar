<?php
function admin_register_head() {
	echo "<link rel='stylesheet' href='http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css'>";
	echo "<link rel='stylesheet' href='//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css'>";
	echo "<link rel='stylesheet' href='//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-theme.min.css'>";
	echo "<script src='//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js'></script>";
	echo "<script src='http://code.jquery.com/jquery-1.9.1.js'></script>";
	echo "<script src='http://code.jquery.com/ui/1.10.3/jquery-ui.js'></script>";
}
add_action ( 'admin_head', 'admin_register_head' );

add_action ( "admin_menu", "milMenus" );
add_action ( "admin_menu", "commMenus" );
function milMenus() {
	add_menu_page ( 'Military', 'Military', 'manage_options', 'militarypage', 'military', get_theme_root_uri () . '/kalmar/plugins/icons/mil.png', 6 );
	add_submenu_page ( "militarypage", "militaryindustries", "Featured Video", 0, "mil-industries", "milIndustries" );
	add_submenu_page ( "militarypage", "militaryproducts", "Products", 0, "mil-products", "militaryProduct" );
	add_submenu_page ( "militarypage", "militarysupport", "Support / Services", 0, "mil-support-services", "milSupport" );
}
function commMenus() {
	add_menu_page ( 'custom menu title2', 'Commercial', 'manage_options', 'commercialpage', 'commercial', get_theme_root_uri () . '/kalmar/plugins/icons/comm.png', 7 );
	add_submenu_page ( "commercialpage", "commercialproducts", "Products", 0, "comm-products", "commercialProducts" );
	add_submenu_page ( "commercialpage", "commercialsupport", "Support / Services", 0, "comm-support-services", "commercialSupport" );
	add_submenu_page ( "commercialpage", "commercialindustries", "Industries", 0, "com-industries", "commercialIndustries" );
}

/*
 * Add military Home Form #########################################################################################
 */
function military() {
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	} else {
		require_once (get_theme_root () . '/Kalmar/plugins/military.php');
	}
}

/*
 * Add military Products #########################################################################################
 */
function militaryProduct() {
	// echo get_theme_root().'/plugins/mil_products.php';
	Require_once (get_theme_root () . '/Kalmar/plugins/core/theme_classes_init.php');
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
		// ############PRODUCT INPUTS############
		$errors = array ();
		$clean_products_array = array ();
		$clean_attributes_array = array ();
		$clean_specs_array = array ();
		$clean_gallery_array = array ();
		
		if (isset ( $_POST ['mil_product_name'] ) && ! empty ( $_POST ['mil_product_name'] ) && isset ( $_POST ['mil_product_desc'] ) && ! empty ( $_POST ['mil_product_desc'] ) && isset ( $_FILES ['mil_product_image'] ) && ! empty ( $_FILES ['mil_product_image'] )) {
			
			$validProductText = new ValidFluent ( $_POST );
			
			$validProductText->name ( 'mil_product_name' )->required ()->alfaNum ()->maxSize ( pow ( 2, 24 ) - 1 );
			$validProductText->name ( 'mil_product_desc' )->required ()->alfaNum ()->maxSize ( pow ( 2, 24 ) - 1 );
			
			if ($validProductText->isGroupValid ()) {
				$clean_products_array ['name'] = $validProductText->getValue ( 'mil_product_name' );
				$clean_products_array ['description'] = $validProductText->getValue ( 'mil_product_name' );
				$allowedExts = array (
						"gif",
						"jpeg",
						"jpg",
						"png" 
				);
				$temp = explode ( ".", $_FILES ["mil_product_image"] ["name"] );
				$extension = end ( $temp );
				if ((($_FILES ["mil_product_image"] ["type"] == "image/gif") || ($_FILES ["mil_product_image"] ["type"] == "image/jpeg") || ($_FILES ["mil_product_image"] ["type"] == "image/jpg") || ($_FILES ["mil_product_image"] ["type"] == "image/pjpeg") || ($_FILES ["mil_product_image"] ["type"] == "image/x-png") || ($_FILES ["mil_product_image"] ["type"] == "image/png")) && ($_FILES ["mil_product_image"] ["size"] < 4 * 1048576) && in_array ( $extension, $allowedExts )) {
					if ($_FILES ["mil_product_image"] ["error"] > 0) {
						echo "Return Code: " . $_FILES ["mil_product_image"] ["error"] . "<br>";
					} else {
						$product_image_name = time () . '.' . $extension;
						// echo "Upload: " . $_FILES ["mil_product_image"] ["name"] . "<br>";
						// echo "Type: " . $_FILES ["mil_product_image"] ["type"] . "<br>";
						// echo "Size: " . ($_FILES ["mil_product_image"] ["size"] / 1048576) . " mb<br>";
						// echo "Temp file: " . $_FILES ["mil_product_image"] ["tmp_name"] . "<br>";
						
						if (file_exists ( get_theme_root () . "/Kalmar/images/product_images/" . $product_image_name )) {
							echo $product_image_name . " already exists. ";
						} else {
							
							move_uploaded_file ( $_FILES ["mil_product_image"] ["tmp_name"], get_theme_root () . "/Kalmar/images/product_images/" . $product_image_name );
							$clean_products_array ['image_location'] = get_theme_root () . "/Kalmar/images/product_images/" . $product_image_name;
							require_once (get_theme_root () . '/Kalmar/plugins/classes/Product.class.php');
							try {
								$name = $clean_products_array ['name'];
								$image_location = $clean_products_array ['image_location'];
								$description = $clean_products_array ['description'];
								global $product_id;
								$product_id = Product::addProduct ( $name, $image_location, $description, true );
							} catch ( Exception $e ) {
								echo $e->getMessage ();
							}
						}
					}
				} else {
					echo "Invalid file<br>";
				}
			} else {
				if (! $validProductText->isValid ( 'mil_product_name' )) {
					echo '<div class="alert alert-danger" id="productNameError">' . $validProductText->getError ( 'mil_product_name' ) . '</div>';
				}
				if (! $validProductText->isValid ( 'mil_product_desc' )) {
					echo '<div class="alert alert-danger" id="productDescError">' . $validProductText->getError ( 'mil_product_desc' ) . '</div>';
				}
			}
		}
		
		echo '<br>';
		/*
		 * ############PRODUCT INPUTS############ name: image: Description:
		 */
		// get features inputs
		$features_inputs = new ValidFluent ( $_POST );
		
		// Engine
		$features_inputs->name ( 'mil_engine_make' )->alfaNum ();
		$features_inputs->name ( 'mil_engine_model' )->alfaNum ();
		$features_inputs->name ( 'mil_engine_cylinders' )->alfaNum ();
		$features_inputs->name ( 'mil_engine_power' )->alfaNum ();
		$features_inputs->name ( 'mil_engine_displacement' )->alfaNum ();
		$features_inputs->name ( 'mil_engine_cooling' )->alfaNum ();
		$features_inputs->name ( 'mil_engine_fuel' )->alfaNum ();
		// Performance
		$features_inputs->name ( 'mil_performance_speedLaden' )->alfaNum ();
		$features_inputs->name ( 'mil_performance_speedReverse' )->alfaNum ();
		$features_inputs->name ( 'mil_performance_gradeability' )->alfaNum ();
		$features_inputs->name ( 'mil_performance_unladen' )->alfaNum ();
		$features_inputs->name ( 'mil_performance_laden' )->alfaNum ();
		$features_inputs->name ( 'mil_performance_fordingDepth' )->alfaNum ();
		// Transmission
		$features_inputs->name ( 'mil_transmission_make' )->alfaNum ();
		$features_inputs->name ( 'mil_transmission_model' )->alfaNum ();
		$features_inputs->name ( 'mil_transmission_type' )->alfaNum ();
		$features_inputs->name ( 'mil_transmission_gears' )->alfaNum ();
		// Weight
		$features_inputs->name ( 'mil_weight_curb' )->alfaNum ();
		$features_inputs->name ( 'mil_weight_frontAxelWeight' )->alfaNum ();
		$features_inputs->name ( 'mil_weight_rearAxelWeight' )->alfaNum ();
		// Axel
		$features_inputs->name ( 'mil_axel_make' )->alfaNum ();
		$features_inputs->name ( 'mil_axel_frontModel' )->alfaNum ();
		$features_inputs->name ( 'mil_axel_rearModel' )->alfaNum ();
		// Service
		$features_inputs->name ( 'mil_service_fuel' )->alfaNum ();
		$features_inputs->name ( 'mil_service_hydraulic' )->alfaNum ();
		// Tires
		$features_inputs->name ( 'mil_tire_size' )->alfaNum ();
		// Brakes
		$features_inputs->name ( 'mil_brake_seervice' )->alfaNum ();
		$features_inputs->name ( 'mil_parking_brake' )->alfaNum ();
		// Other
		$features_inputs->name ( 'mil_electrical_system' )->alfaNum ();
		$features_inputs->name ( 'mil_alternator' )->alfaNum ();
		// Spec Sheet
		if ($features_inputs->isGroupValid ()) {
			//Engine
			$clean_specs_array['mil_engine_make'] = $features_inputs->getValue('mil_engine_make');
			$clean_specs_array['mil_engine_model'] = $features_inputs->getValue('mil_engine_model');
			$clean_specs_array['mil_engine_cylinders'] = $features_inputs->getValue('mil_engine_cylinders');
			$clean_specs_array['mil_engine_power'] = $features_inputs->getValue('mil_engine_power');
			$clean_specs_array['mil_engine_displacement'] = $features_inputs->getValue('mil_engine_displacement');
			$clean_specs_array['mil_engine_cooling'] = $features_inputs->getValue('mil_engine_cooling');
			$clean_specs_array['mil_engine_fuel'] = $features_inputs->getValue('mil_engine_fuel');
			//Performance
			$clean_specs_array['mil_performance_speedLaden'] = $features_inputs->getValue('mil_performance_speedLaden');
			$clean_specs_array['mil_performance_speedReverse'] = $features_inputs->getValue('mil_performance_speedReverse');
			$clean_specs_array['mil_performance_gradeability'] = $features_inputs->getValue('mil_performance_gradeability');
			$clean_specs_array['mil_perfomance_unladen'] = $features_inputs->getValue('mil_performance_unladen');
			$clean_specs_array['mil_perfomance_laden'] = $features_inputs->getValue('mil_performance_laden');
			$clean_specs_array['mil_performance_fordingDepth'] = $features_inputs->getValue('mil_performance_fordingDepth');
			//Transmission
			$clean_specs_array['mil_transmission_make'] = $features_inputs->getValue('mil_trasmission_make');
			$clean_specs_array['mil_transmission_model'] = $features_inputs->getValue('mil_transmission_model');
			$clean_specs_array['mil_tranmission_type'] = $features_inputs->getValue('mil_transmission_type');
			$clean_specs_array['mil_tranmission_gears'] = $features_inputs->getValue('mil_transmission_gears');
			//weight
			$clean_specs_array['mil_weight_curb'] = $features_inputs->getValue('mil_weight_curb');
			$clean_specs_array['mil_frontAxelWeight'] = $features_inputs->getValue('mil_weight_frontAxelWeight');
			$clean_specs_array['mil_rearAxelWeight'] = $features_inputs->getValue('mil_weight_rearAxelWeight');
			//Axel
			$clean_specs_array['mil_axel_make'] = $features_inputs->getValue('mil_axel_make');
			$clean_specs_array['mil_axel_model'] = $features_inputs->getValue('mil_axel_frontModel');
			$clean_specs_array['mil_axel_rearModel'] = $features_inputs->getValue('mil_axel_rearModel');
			//Service
			$clean_specs_array['mil_service_fuel'] = $features_inputs->getValue('mil_service_fuel');
			$clean_specs_array['mil_service_hydraulic'] = $features_inputs->getValue('mil_service_hydraulic');
			//Tires
			$clean_specs_array['mil_tire_size'] = $features_inputs->getValue('mil_tire_size');
			//Brakes
			$clean_specs_array['mil_brake_service'] = $features_inputs->getValue('mil_brake_service');
			$clean_specs_array['mil_parking_service'] = $features_inputs->getValue('mil_parking_service');
			//Other
			$clean_specs_array['mil_electrical_system'] = $features_inputs->getValue('mil_electrical_system');
			$clean_specs_array['mil_alternator'] = $features_inputs->getValue('mil_alternator');
			
			$clean_specs_array['mil_product_id'] = $product_id;
			
			
			if (! empty ( $_FILES ['mil_spec_sheet'] )) {
				$specSheetAllowed = array('pdf');
				$specSheetTemp = explode ( ".", $_FILES ["mil_spec_sheet"] ["name"] );
				$specSheetExtension = end ( $specSheetTemp );
				if (in_array ( $specSheetExtension, $specSheetAllowed )) {
					
					
					//###############Add code to save spec sheet################
					$spec_sheet_name = time().'.pdf';
					move_uploaded_file ( $_FILES ["mil_spec_sheet"] ["tmp_name"], get_theme_root () . "/Kalmar/plugins/spec_Sheets/". $spec_sheet_name );
					$clean_specs_array ['spec_sheet'] =  get_theme_root () . "/Kalmar/plugins/spec_Sheets/". $spec_sheet_name;
					
					require_once (get_theme_root () . '/Kalmar/plugins/classes/addFeature.class.php');
						
					Feature::addFeature($clean_specs_array);
				} else {
					echo $_FILES['mil_spec_sheet']['name'];
					echo '<div class="alert alert-danger">Spec Sheet must be in PDF format</div>';
				}
			}
		}else {
			echo '<div class="alert alert-danger">Error with your specifications</div>';
		}
		
		$posts = $_FILES;
		foreach ( $posts as $postKey => $postValue ) {
			echo $postKey . ': ' . $postValue . '<br>';
		}
		
		/*
		 * ############FEATURES INPUTS############ # OF FEATURES: TITLE: IMAGE: BULLETS:
		 */
		// get specs inputs
		/*
		 * ############SPECIFICATIONS INPUTS############ /* Engine: Performance: Transmission: Weight: Axels: Service Capacity: Tires: Brakes: Additional data: Specs Sheet:
		 */
		// get gallery inputs
		/*
		 * ############Gallery INPUTS############ Images: Videos:
		 */
	}
	require_once (get_theme_root () . '/Kalmar/plugins/mil_products.php');
}

/*
 * Military Support/Services #########################################################################################
 */
function milSupport() {
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	} else {
		require_once (get_theme_root () . '/Kalmar/plugins/mil_support.php');
	}
}

/*
 * Military Industries #########################################################################################
 */
function milIndustries() {
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	} else {
		require_once (get_theme_root () . '/Kalmar/plugins/mil_industries.php');
	}
}

/*
 * Commercial Home #########################################################################################
 */
function commercial() {
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	} else {
		?>
<p>This is the commercial landing page</p>

<h1>Add Product</h1>
<h1>Add feature</h1>
<h1>Add Specifications</h1>
<h1>Add Gallery</h1><?php
	}
}

/*
 * Commercial Products #########################################################################################
 */
function commercialProducts() {
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	} else {
		?>
<p>This is the commercial landing page</p>

<h1>Add Product</h1>
<h1>Add feature</h1>
<h1>Add Specifications</h1>
<h1>Add Gallery</h1><?php
	}
}

/*
 * Commercial Support/Services #########################################################################################
 */
function commercialSupport() {
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	} else {
		?>
<p>This is the commercial landing page</p>

<h1>Add Product</h1>
<h1>Add feature</h1>
<h1>Add Specifications</h1>
<h1>Add Gallery</h1><?php
	}
}

/*
 * Commercial Industries #########################################################################################
 */
function commercialIndustries() {
	if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	} else {
		?>
<p>This is the commercial landing page</p>

<h1>Add Product</h1>
<h1>Add feature</h1>
<h1>Add Specifications</h1>
<h1>Add Gallery</h1><?php
	}
}

/*
 * ########################## Navigation Registration ###########################
 */
function register_my_comm_menu() {
	register_nav_menu ( 'comm-header-menu', __ ( 'Com Header Menu' ) );
}
add_action ( 'init', 'register_my_comm_menu' );
function register_my_mil_menu() {
	register_nav_menu ( 'mil-header-menu', __ ( 'Mil Header Menu' ) );
}
add_action ( 'init', 'register_my_mil_menu' );
function register_my_mil_tan_menu() {
	register_nav_menu ( 'mil-tan-header-menu', __ ( 'mil tan Header Menu' ) );
}
add_action ( 'init', 'register_my_mil_tan_menu' );
function register_my_comm_tan_menu() {
	register_nav_menu ( 'comm-tan-header-menu', __ ( 'comm tan Header Menu' ) );
}
add_action ( 'init', 'register_my_comm_tan_menu' );

/*
 * ########################## END Navigation Registration ###########################
 */



/*
########################## Create Database Tables ###########################
*/
$mil_product = $wpdb->prefix . 'mil_product';
$mil_features = $wpdb->prefix . 'mil_features';
$mil_specs = $wpdb->prefix . 'mil_specs';
$mil_gallery = $wpdb->prefix . 'mil_gallery';

// function to create the DB / Options / Defaults
function your_plugin_options_install() {
	global $wpdb;
	global $your_db_name;
	
	// create the ECPT metabox database table
	if ($wpdb->get_var ( "show tables like '$your_db_name'" ) != $mil_product) {
		$sql = "CREATE TABLE " . $mil_product . " (
		`mil_product_id` int(11) NOT NULL AUTO_INCREMENT,
		`mil_product_name` mediumtext NOT NULL,
		`mil_product_image` mediumtext NOT NULL,
		`mil_product_desc` mediumtext NOT NULL,
		UNIQUE KEY id (mil_product_id)
		);";
		
		require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta ( $sql );
	}
	
	if ($wpdb->get_var ( "show tables like '$your_db_name'" ) != $mil_feature) {
		$sql = "CREATE TABLE " . $mil_feature . " (
		`mil_feature_id` int(11) NOT NULL AUTO_INCREMENT,
		`mil_feature_title` mediumtext NOT NULL,
		`mil_feature_image` mediumtext NOT NULL,
		`mil_feature_bullets` mediumtext NOT NULL,
		`mil_product_id` int(11) NOT NULL,
		UNIQUE KEY id (mil_feature_id)
		);";
		
		require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta ( $sql );
	}
	
	if ($wpdb->get_var ( "show tables like '$your_db_name'" ) != $mil_specs) {
		$sql = "CREATE TABLE " . $mil_specs . " (
		`mil_specs_id` int(11) NOT NULL AUTO_INCREMENT,
		`mil_engine_make` tinytext NOT NULL,
		`mil_engine_model` tinytext NOT NULL,
		`mil_engine_cylinders` tinytext NOT NULL,
		`mil_engine_power` tinytext NOT NULL,
		`mil_engine_displacement` tinytext NOT NULL,
		`mil_engine_cooling` tinytext NOT NULL,
		`mil_engine_fuel` tinytext NOT NULL,
		
		`mil_performance_speedUnladen` tinytext NOT NULL,
		`mil_performance_speedLaden` tinytext NOT NULL,
		`mil_performance_speedReverse` tinytext NOT NULL,
		`mil_performance_gradeability` tinytext NOT NULL,
		`mil_performance_unladen` tinytext NOT NULL,
		`mil_performance_laden` tinytext NOT NULL,
		`mil_performance_fordingDepth` tinytext NOT NULL,
		
		`mil_transmission_make` tinytext NOT NULL,
		`mil_transmission_model` tinytext NOT NULL,
		`mil_transmission_type` tinytext NOT NULL,
		`mil_transmission_gears` tinytext NOT NULL,
		
		`mil_weight_curb` tinytext NOT NULL,
		`mil_weight_frontAxelWeight` tinytext NOT NULL,
		`mil_weight_rearAxelWeight` tinytext NOT NULL,
		
		`mil_axel_make` tinytext NOT NULL,
		`mil_axel_frontModel` tinytext NOT NULL,
		`mil_axel_rearModel` tinytext NOT NULL,
		
		`mil_service_fuel` tinytext NOT NULL,
		`mil_service_hydraulic` tinytext NOT NULL,
		
		`mil_tire_size` tinytext NOT NULL,
		
		`mil_brake_service` tinytext NOT NULL,
		`mil_brake_parking` tinytext NOT NULL,
		
		`mil_electrical_system` tinytext NOT NULL,
		`mil_alternator` tinytext NOT NULL,
		
		`mil_spec_sheet` tinytext NOT NULL,
		
		`mil_product_id` int(11) NOT NULL,
		UNIQUE KEY id (mil_specs_id)
		);";
		
		require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta ( $sql );
	}
	
	if ($wpdb->get_var ( "show tables like '$your_db_name'" ) != $mil_gallery) {
		$sql = "CREATE TABLE " . $mil_gallery . " (
		`mil_gallery_id` int(11) NOT NULL AUTO_INCREMENT,
		`mil_gallery_type` mediumtext NOT NULL,
		'mil_gallery_url' mediumtext NOT NULL,
		`mil_product_id` int(11) NOT NULL,
		UNIQUE KEY id (mil_gallery_id)
		);";
		
		require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta ( $sql );
	}
}
// run the install scripts upon plugin activation
register_activation_hook ( __FILE__, 'your_plugin_options_install' );

/*
 * ########################## END Create Database Tables ###########################
 */



/*
########################## Register Widgets ###########################
*/
if (function_exists ( 'register_sidebar' )) {
	register_sidebar ( array (
			'name' => 'Left Footer Widgets',
			'id' => 'Left Footer Widgets',
			'description' => '3 Column and logo area footer',
			'before_widget' => '<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">',
			'after_widget' => '</div>',
			'before_title' => '<h1>',
			'after_title' => '</h1>' 
	) );
}

if (function_exists ( 'register_sidebar' )) {
	register_sidebar ( array (
			'name' => 'Center Footer Widgets',
			'id' => 'Center Footer Widgets',
			'description' => '3 Column and logo area footer',
			'before_widget' => '<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">',
			'after_widget' => '</div>',
			'before_title' => '<h1>',
			'after_title' => '</h1>' 
	) );
}

if (function_exists ( 'register_sidebar' )) {
	register_sidebar ( array (
			'name' => 'Right Footer Widgets',
			'id' => 'Right Footer Widgets',
			'description' => '3 Column and logo area footer',
			'before_widget' => '<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">',
			'after_widget' => '</div>',
			'before_title' => '<h1>',
			'after_title' => '</h1>' 
	) );
}

/*
 * ########################## END Register Widgets ###########################
 */




/*
########################## Register CSS and Javascript ###########################
*/
function theme_name_scripts() {
	wp_enqueue_style ( 'base_css', get_stylesheet_uri () );
	wp_enqueue_style ( 'bootstrap_css', '//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css' );
	wp_enqueue_style ( 'bootstrap_theme_css', '//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css' );
	wp_enqueue_style ( 'jquery_ui_css', 'http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css' );
	wp_enqueue_script ( 'jquery-1.10.2', '//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js', array (), '1.0.0', true );
	wp_enqueue_script ( 'jquery-1.9.1', 'http://code.jquery.com/jquery-1.9.1.js', array (), '1.0.0', true );
	wp_enqueue_script ( 'jquery-ui', 'http://code.jquery.com/ui/1.10.3/jquery-ui.js', array (), '1.0.0', true );
	wp_enqueue_script ( 'bootstrap-js', '//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js', array (), '1.0.0', true );
}

add_action ( 'wp_enqueue_scripts', 'theme_name_scripts' );

/*
 * ########################## END Register CSS and Javascript ###########################
 */
?>