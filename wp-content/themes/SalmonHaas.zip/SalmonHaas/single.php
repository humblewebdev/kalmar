<?php get_header();?>

<!-- Content area - this is the inner box for content -->
	<div id="content">
<!-- Start of grey area for content -->
		<div id="content_wrapper" class="wrapper">
<!-- Start of blog article -->			
	<div class="post_single">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<h1 class="page_header"><?php the_title(); ?></h1>
		<hr />
			<p><?php the_content(__('(more...)')); ?></p> 
				<?php endwhile; else: ?>
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
	</div>
<!-- end of blog article text box -->
<!-- Start of Blog Sidebar -->
		<div class="blog_sidebar">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Blog') ) : ?>
			<?php endif; ?>
		</div>
		<div class="clear"></div>
<!-- end of sidebar -->
</div>
<!-- end of content wrapper -->
</div>
<!-- end of content -->
<div class="clear"></div>
<?php get_footer();?>