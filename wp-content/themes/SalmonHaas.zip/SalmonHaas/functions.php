<?php
/**
 * Register our sidebars and widgetized areas.
 *
 */


if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'content_right_contact_form',
'id'   => 'content_right_contact_form',
'description'   => 'Gray Box for Contact form',
'before_widget' => '<div class="contact_form">',
'after_widget' => '</div>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'content_right_testimonials_widget_area',
'id'   => 'content_right_testimonials_widget_area',
'description'   => 'Widgets',
'before_widget' => '',
'after_widget' => ''
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'content_left_row1',
'id'   => 'content_left_row1',
'description'   => 'Format
<img class="shadow">
<h1></h1>
<h2></h2>
',
'before_widget' => '<li>',
'after_widget' => '</li>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'content_left_row2',
'id'   => 'content_left_row2',
'description'   => 'Format
<img class="shadow">
<h1></h1>
<h2></h2>
',
'before_widget' => '<li>',
'after_widget' => '</li>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'content_left_row3',
'id'   => 'content_left_row3',
'description'   => 'Format
<img class="shadow">
<h1></h1>
<h2></h2>
',
'before_widget' => '<li>',
'after_widget' => '</li>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'content_left_row4',
'id'   => 'content_left_row4',
'description'   => 'Format
<img class="shadow">
<h1></h1>
<h2></h2>
',
'before_widget' => '<li>',
'after_widget' => '</li>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'Page Sidebar',
'id'   => 'Page Sidebar',
'description'   => 'Appears on all pages with sidebar',
'before_widget' => '<ul><li>',
'after_widget' => '</li></ul>',
'before_title' => '<h2>',
'after_title' => '</h2>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'Footer Widgets Left',
'id'   => 'Footer Widgets Left',
'description'   => 'First Column in Footer',
'before_widget' => '<li>',
'after_widget' => '</li>',
'before_title' => '<h3>',
'after_title' => '</h3>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'Footer Widgets Middle',
'id'   => 'Footer Widgets Middle',
'description'   => 'Second Column in Footer',
'before_widget' => '<li>',
'after_widget' => '</li>',
'before_title' => '<h3>',
'after_title' => '</h3>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'Footer Widgets Right',
'id'   => 'Footer Widgets Right',
'description'   => 'Third Column in Footer',
'before_widget' => '<li>',
'after_widget' => '</li>',
'before_title' => '<h3>',
'after_title' => '</h3>'
));


if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'Footer Widgets Social',
'id'   => 'Footer Widgets Social',
'description'   => 'Last Column in Footer',
'before_widget' => '<li>',
'after_widget' => '</li>',
'before_title' => '<h3>',
'after_title' => '</h3>'
));

if ( function_exists('register_sidebar') )
register_sidebar(array(
'name' => 'Blog',
'id'   => 'Blog',
'description'   => 'Sidebar for Blog',
'before_widget' => '<ul><li>',
'after_widget' => '</li></ul>',
'before_title' => '<h2>',
'after_title' => '</h2>'
));


function register_my_menu() {
  register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_my_menu' );

// Replaces the excerpt "more" text by a link
function new_excerpt_more($more) {
       global $post;
	return '<a class="moretag" href="'. get_permalink($post->ID) . '"> Read the full article...</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');
?>