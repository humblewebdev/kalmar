<?php get_header(); ?>

	<div id="main">
		
		<div id="content">
		
			<h3 id="lostinspace"><a href="<?php bloginfo('url'); ?>"><?php echo of_get_option('404_message', 'WTF? GOT LOST?'); ?></a></h3>
						
		</div>
		
	</div>

<?php get_footer(); ?>