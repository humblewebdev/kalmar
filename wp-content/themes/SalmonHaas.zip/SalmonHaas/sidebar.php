<div id="sidebar">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Page Sidebar') ) : ?>
		<li>
		<?php endif; ?>
	</ul><div class="clear"></div>
</div>