<html>
<head>
<title>Salmon and Haas</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="Author" content="Webtegrity">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="Revisit-After" content="7 Days">
<meta name="robots" content="index,follow">
<link rel="shortcut icon" href="/favicon.ico">
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
</head>
<body>
<!-- Top Grey Bar Full Length of Site -->
<div class="fullbar"></div>

<!-- end of Grey Bar -->
<?php echo do_shortcode( $content ) ?> 
<!-- Start of Header -->
<div class="header_wrapper">
<!-- Start of Inner Header space with Logo and CTA -->
<div class="header_logo">
<a href="http://www.salmonhaas.com/" title="Lawyers in San Antonio"><img src="http://www.salmonhaas.com/wp-content/uploads/2013/09/immigration_lawyers_san_antonio.png" alt="salmon and haas" title="immigration lawyers"></a>


<!-- Top Right Call to Action -->
<div class="topcta">
Call to get a Free Consultation
<br /><span>210-734-8472</span>
<p>Se Habla Español</p>
</div>
<!-- end of Top Right CTA -->

<div class="clear"></div>

</div>
<!-- end of header logo area -->
</div>
<!-- end of header wrapper-->



<!-- Navigation -->
<div id="navbar">
<?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>

</div>
<!-- end of navigation -->