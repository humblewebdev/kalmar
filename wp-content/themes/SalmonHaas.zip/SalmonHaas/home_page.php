<?php
/*
Template Name: Home Page
*/
?>

<?php get_header(); ?>

<!-- Only displays on the Homepage -->
<?php if(is_front_page()){?>
<!-- Start of Slideshow -->
	<div class="slider_wrapper">
		<div class="slider_hm">
			<?php putRevSlider("slider1","homepage") ?> 
		</div>
	</div>
<!-- end of slideshow -->
	<div class="clear"></div>

<!-- Start of Blue Line for CTA -->
	<div class="blue">
		<div class="blue_wrapper wrapper">
			<div class="learn_more">
				<div class="CTA">
					<h1>We’ll take time to listen to you.</h1>
					<h2>Call for your FREE Consultation.</h2>
				</div>
		<a href=""><img src="http://www.salmonhaas.com/wp-content/uploads/2013/09/learn_more.png" alt="Learn More Button" title="Free Consultation"></a>
			</div>
				<div class="directions">
				<a href=""><img src="http://www.salmonhaas.com/wp-content/uploads/2013/09/office_location.png" title="Get Directions" class="" alt="lawyer office in San Antonio">
		<p>Get Directions<br>To Our Office >><p></a>
				</div>
		</div>
	</div>
<!-- end of Blue line for cta -->

<!-- Content area - this is the inner box for content -->
	<div id="content">
		<div id="content_wrapper" class="wrapper">
		
			
			<?php if(is_front_page()){ ?>
			<div class="content_column">
				<ul class="law_types">
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('content_left_row1') ) : ?>
					
					<?php endif; ?>
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('content_left_row2') ) : ?>
					
					<?php endif; ?>
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('content_left_row3') ) : ?>
					
					<?php endif; ?>
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('content_left_row4') ) : ?>
					
					<?php endif; ?>
				</ul>
			</div>
			
			<div class="content_column">
				
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('content_right_contact_form') ) : ?>
					
					<?php endif; ?>
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('content_right_testimonials_widget_area') ) : ?>
					
					<?php endif; ?>
			</div>
			
			
			<div class="clear"></div>
			<?php 	}
			//$recent = new WP_Query("page_id=34"); while($recent->have_posts()) : $recent->the_post();?>
			<?php //the_content(); ?>
			<?php //endwhile; ?>
		</div>
	</div>
<!--  end of container  -->
<div id="delimiter"></div>
<?php } ?>
<?php get_footer(); ?>