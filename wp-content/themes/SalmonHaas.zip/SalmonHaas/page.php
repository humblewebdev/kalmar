<?php get_header();?>


	<div id="content">
<!-- Content area - this is the inner box for content -->
		<div id="content_wrapper" class="wrapper">
			<!-- Body of Page Text -->
			<div class="pg_text">
				<?php if (have_posts()) : ?>
				<?php while (have_posts()) : the_post(); ?>
			
					<div id="page_content">
					<?php the_content(); ?>
					</div>
				<?php endwhile; ?>
			<?php endif; ?>
			</div>
<!-- end of Page Text Area -->
<!-- Get Sidebar -->
			<div class="right_sidebar">
				 <?php get_sidebar(); ?> 
			</div>
<div class="clear"></div>
<!-- end of sidebar -->
		
		</div>
<div class="clear"></div>
<!-- end of inner content wrapper -->

	</div>
<!-- end of content -->
<div class="clear"></div>
<?php get_footer();?>