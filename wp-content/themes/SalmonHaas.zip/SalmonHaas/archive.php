<?php get_header(); ?>


<!-- Content area - this is the inner box for content -->
	<div id="content">
<!-- Start of grey area for content -->
		<div id="content_wrapper" class="wrapper">
<!-- Start of blog listings -->			
			<div class="archives_list">
				<?php if (have_posts()) : ?>
				<?php while (have_posts()) : the_post(); ?>
					<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
					<?php if ( is_category() || is_archive() ) {
						the_excerpt();
						} else {
							the_content();
						} ?>
					<hr />
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
					
<!-- Start of Sidebar -->
		<div class="right_sidebar">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Blog') ) : ?><?php endif; ?>
			
		</div><div class="clear"></div>
		<!-- end of Sidebar -->

</div>
<!-- end of content wrapper -->

</div>
<!-- end of Content Area -->
<?php get_footer(); ?>