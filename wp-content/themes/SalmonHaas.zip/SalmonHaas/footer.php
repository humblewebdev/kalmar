<!-- Start of Footer -->
<div id="footer">
	<div id="footer_wrapper" class="wrapper">
		<div class="footer_left">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widgets Left') ) : ?>
		<li>
		<?php endif; ?>
	</ul></div>
		
		<div class="footer_middle">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widgets Middle') ) : ?>
		<li>
		<?php endif; ?>
	</ul></div>
		
		<div class="footer_right">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widgets Right') ) : ?>
		<li>
		<?php endif; ?>
	</ul></div>
		
		<div class="footer_social">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widgets Social') ) : ?>
		<li>
		<?php endif; ?>
	</ul></div>
	<div class="clear"></div>
</div>
<!--  END footer_wrapper  -->
</div>
<!--  END footer  -->

<!-- Copyright Area -->
<div class="copyright_container">
	<div class="copyright">
	All Content &copy; Copyright Salmon and Haas 2012-<?php echo date("Y") ?> |  Privacy Policy   |   Terms of Use  <br /><a href="http://webtegrity.com/" target="_blank">Webdesign</a> by Webtegrity
	</div></div>
<!-- End of Copyright -->

</body>
</html>