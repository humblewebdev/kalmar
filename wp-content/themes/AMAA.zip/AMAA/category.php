<?php
/**
 * The template for displaying Category pages.
 *
 */
?>

<?php get_header(); ?>


<!-       START Content Masonry       ->

<div class="main-content col-xs-12 col-sm-12 col-md-12 col-lg-12">


    <!-          START Intro Content       ->



    <div class="box col-xs-12 col-sm-12 col-md-12 col-lg-12">

        <div class="category-content">
            <?php if (have_posts()) : ?>
                <header class="archive-header">
                    <h1 class="archive-title"><?php printf(__('Category Archives: %s', 'amaa'), single_cat_title('', false)); ?></h1>

                    <?php if (category_description()) : // Show an optional category description  ?>
                        <div class="archive-meta"><?php echo category_description(); ?></div>
                    <?php endif; ?>
                </header><!-- .archive-header -->

        
</div>
<!-        END Content       ->
        
                <?php
                	
                	$cat = $_GET['cat'];
                	$args = array('category' => $cat );
                	$posts = get_posts( $args );
					
                	foreach($posts as $post){
                		//var_dump($post);
                	?>
                	<div class="category-content">
                        <?php if ( has_post_thumbnail($post->ID) ) { 
  							the_post_thumbnail($post->ID);
  						} ?>
                        <h3><?php echo $post->post_title; ?></h3>
                
                    <p><?php echo $post->post_content ?></p>
                    
                    <div class="clear"></div>
                    </div>	
                	<?php } ?>

                    
<!-      END Content      ->
                
                
                <?php
             else : 
                 get_template_part('content', 'none'); 
 endif; 
 
 wp_reset_query();
 
 ?>
        

            <div class="clear"></div>


        </div><!-       END Box       ->
        
        
            <div class="row">
        <a href="#"><div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3">
                <h3 class="ask-button">ASK QUESTIONS</h3>
            </div></a>

    </div>

    </div><!-          END Main Content        ->



















</div><!------------END Wrapper----------> 

<?php include (TEMPLATEPATH . '/footer2.php'); ?>