<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php wp_title('|'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="Revisit-After" content="7 Days">
        <meta name="robots" content="index,follow">
        <link rel="shortcut icon" href="/favicon.ico">

        <!-- JQuery -->



        <!-- Bootstrap 
         <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
         <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
        
        <script src="/AMAA/js/bootstrap.min.js"></script>

        -->
        <!-- MAIN STYLE 
        <link href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" rel="stylesheet" media="screen">
        <link href="/AMAA/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
        
        
        <link href='http://fonts.googleapis.com/css?family=Chau+Philomene+One' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
        
        -->
        
        <?php
        
        wp_head();
        
        ?>




    </head>
    <body>
        <!------------START Wrapper---------->

        <div class="wrapper">

            <!------------START Header---------->

            <header>

                <!------------START Social Icons---------->

                <div class="social-icons">
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/rss-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/linkedin-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/instagram-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/twitter-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/you-tube-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook-icon.png" alt=""></a></div>

                </div>

                <!------------END Social Icons---------->

                <!------------START Logo---------->

                <div class="logo">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/AMAA New Logo.png" alt="American Martial Arts Academy" />
                </div>
                <!------------END Logo----------> 

                <!------------START Nav----------> 



                <?php
                $defaults = array(
                    'theme_location' => '',
                    'menu' => '',
                    'container' => 'div',
                    'container_class' => '',
                    'container_id' => '',
                    'menu_class' => 'menu',
                    'menu_id' => '',
                    'echo' => true,
                    'fallback_cb' => 'wp_page_menu',
                    'before' => '',
                    'after' => '',
                    'link_before' => '',
                    'link_after' => '',
                    'items_wrap' => '<nav class="mainnav" role="navigation">  <!-- Brand and toggle get grouped for better mobile display -->
  
  <div class="menu-button-wrapper">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      
    </button>
    <h3 class="mobile-menu" data-toggle="collapse" data-target=".navbar-ex1-collapse"><a href="#">MENU</a></h3>
    <div class="clear"></div>
    </div>
    


  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse navbar-ex1-collapse"><ul class="nav-ul list-inline">%3$s</ul></div><!-- /.navbar-collapse --></nav>',
                    'depth' => 0,
                    'walker' => ''
                );

                wp_nav_menu($defaults);
                ?>

                <!------------END Nav----------> 


            </header>
