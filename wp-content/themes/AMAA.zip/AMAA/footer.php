<footer>
            <div class="footer-wrapper">
                <?php
                if(!function_exists('dynamic_sidebar')||!dynamic_sidebar('footer_widget')):
                ?>
                
                <?php endif; ?>
                
              
                <div class="clear"></div>
                
                 <div class="alt-social-icons">
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/rss-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/linkedin-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/instagram-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/twitter-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/you-tube-icon.png" alt=""></a></div>
                    <div class="icon"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook-icon.png" alt=""></a></div>

                </div>
            <div class="copyright"><p>© 2013 All content property of American Martial Art Academy Sitemap | San Antonio Web Design by Webtegrity | Comments (RSS)</p></div>
           
            </div>
        </footer>

    </body>
</html>

