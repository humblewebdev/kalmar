<?php
/*
  Template Name: Post Page
 */
?>


<?php get_header(); ?>


<!------------START Content Masonry---------->

<div class="main-content col-xs-12 col-sm-12 col-md-12 col-lg-12">


    <!------------START Intro Content---------->



    <div class="box col-xs-12 col-sm-8 col-md-8 col-lg-8">

        <div class="page-content">
	       <?php $post_meta = get_post_meta(get_the_ID());
            		$has_youtube = false;
            		
            		if(isset($post_meta['Youtube-Video']) && !empty($post_meta['Youtube-Video'][0])){
            			$youtube_video = $post_meta['Youtube-Video'];
            			$has_youtube = true;
            			echo '<br><br>'.$youtube_video[0]; 
            		} else {
            		?>
        <?php if($url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) )){ ?>
            
            <img src="<?php echo $url?>" alt="...">
			<?php 
				}
			} ?>
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            
                    <h2><?php the_title(); ?></h2>
                    <p><?php the_content(__('(more...)')); ?></p>
                    
                    
                   <div class="share-with-container col-xs-12 col-sm-12 col-md-12 col-lg-12">
                       <h4>SHARE THIS</h4>
                       <div class="share-with-box col-xs-12 col-sm-6 col-md-6 col-lg-3">
                           <a href="http://www.facebook.com/sharer.php?u=<?php echo the_permalink(); ?>&t=<?php echo the_title(); ?>" title=”Facebook share button” target=”blank”><img class="page-icon" src="<?php echo get_template_directory_uri(); ?>/images/facebook-icon.png" alt="" width="25px" height="25px"></a>
                           <p class="social-ask">- Share This</p>
                       </div>
                
                       <div class="share-with-box col-xs-12 col-sm-6 col-md-6 col-lg-3">
                           <a href="http://twitter.com/share?url=<?php echo urlencode(get_permalink($post->ID)); ?>" data-lang="en"><img class="page-icon" src="<?php echo get_template_directory_uri(); ?>/images/twitter-icon.png" alt="" width="25px" height="25px"></a>
                           <p class="social-ask">- Tweet This</p>
                       </div>
                       
                       <?php if($has_youtube) {?>
                       <div class="share-with-box col-xs-12 col-sm-6 col-md-6 col-lg-3">
                           <a href="http://www.youtube.com/subscription_center?add_user=MartialArtAcademy"><img class="page-icon" src="<?php echo get_template_directory_uri(); ?>/images/you-tube-icon.png" alt="" width="25px" height="25px"></a>
                           <p class="social-ask">- Subscribe</p>
                       </div>
                       <?php } ?>
                       
                       
                       <?php if($image_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) )){ ?>
                       <div class="share-with-box col-xs-12 col-sm-6 col-md-6 col-lg-3">
                           <a href="http://pinterest.com/pin/create/button/?url=<?php echo get_permalink( $id )?>&media=<?php echo $image_url ?>" class="pin-it-button" count-layout="horizontal" width="25px" height="25px"><img class="page-icon" src="<?php echo get_template_directory_uri(); ?>/images/instagram-icon.png" alt=""></a>
                           <p class="social-ask">- Thumbs Up</p>
                       </div>
                       <?php } ?>
                       
                       
                   </div>
                  
                    <div class="row">
                    <div class="post-tags col-xs-12 col-sm-3 col-md-6 col-lg-6">
                        <?php $tags_array = wp_get_post_tags( $_GET['p'] ); 
                            foreach ($tags_array as $tag){
                            echo '<a href=#>'.$tag -> name.'</a>';
                        
                            }    
                                
                                
                                
                                ?>
                    </div>
                    <?php amaa_post_nav(); ?>
                        


                <?php endwhile;
            else: ?>
                <p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>

          
                    </div>
                <div class="clear"></div>


        </div><!------------END Page-content---------->
        
                

        
    
<?php comments_template(); ?>
            
            
            
            
   

    </div><!------------END Box---------->



    <!------------START Sidebar---------->

<div class="sidebar-box col-xs-12 col-sm-4 col-md-4 col-lg-4">

    <?php
    if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar_widget')):
        ?>

<?php endif; ?>
</div>



    <!------------END Sidebar---------->

    
    

    
    
   


    <div class="row">
        <a href="<?php echo get_home_url().'/?page_id=32'?>"><div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3">
                <h3 class="ask-button">ASK QUESTIONS</h3>
            </div></a>

    </div>






</div>
<!------------END Content---------->







</div><!------------END Wrapper----------> 

<?php include (TEMPLATEPATH . '/footer2.php'); ?>