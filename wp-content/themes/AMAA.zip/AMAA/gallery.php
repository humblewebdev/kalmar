<?php
/*
  Template Name: Gallery Page Template
 */
?>

<?php get_header(); ?>

<!------------START Content Masonry---------->

<div class="main-content col-xs-12 col-sm-12 col-md-12 col-lg-12">


    <!------------START Intro Content---------->


<?php
$posts = get_posts();
$post_IDs = array();
foreach($posts as $post){
	$post_IDs[] = $post->ID;
}

foreach($post_IDs as $post_id){
	$post_meta = get_post_meta($post_id);
		if(isset($post_meta['Youtube-Video']) && !empty($post_meta['Youtube-Video'][0])){
        	$youtube_video = $post_meta['Youtube-Video'][0];
        	
        	$youtube_video = preg_replace('/width="\d+"/', 'width="525"', $youtube_video);
	       	$youtube_video = preg_replace('/height="\d+"/', 'height="350"', $youtube_video);
        	
        	
        	?>
        	 <div class="box col-xs-12 col-sm-8 col-md-8 col-lg-8">

        <div class="gallery-page-content">
        	
        	 <div class="box col-xs-12 col-sm-8 col-md-8 col-lg-8">
                
            <h2>Application of Self Defense</h2>
            
            <?php echo $youtube_video; ?>
            
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                <div class="gallery-read-this-button">
                    <h3><a href="<?php echo get_permalink( $post_id );?>">READ THE ARTICLE</a></h3>
            </div>
            </div>
            
            <div class="video-share-with-container col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
                
                <h4>SHARE THIS</h4>
                
                       <div class="video-share-with-box col-xs-6 col-sm-6 col-md-12 col-lg-12">
                           <a href="http://www.facebook.com/sharer.php?u=<?php echo the_permalink(); ?>&t=<?php echo the_title(); ?>"><img class="page-icon" src="<?php echo get_template_directory_uri()?>/images/facebook-icon.png" alt=""></a>
                           <p class="social-ask">- Share This</p>
                       </div>
                       
                       <div class="video-share-with-box col-xs-6 col-sm-6 col-md-12 col-lg-12">
                           <a href="http://twitter.com/share?url=<?php echo urlencode(get_permalink($post->ID)); ?>"><img class="page-icon" src="<?php echo get_template_directory_uri()?>/images/twitter-icon.png" alt=""></a>
                           <p class="social-ask">- Tweet This</p>
                       </div>
                       
                       <div class="video-share-with-box col-xs-6 col-sm-6 col-md-12 col-lg-12">
                           <a href="http://www.youtube.com/subscription_center?add_user=MartialArtAcademy"><img class="page-icon" src="<?php echo get_template_directory_uri(); ?>/images/you-tube-icon.png" alt=""></a>
                           <p class="social-ask">- Subscribe</p>
                       </div>
                       
                      <!-- <div class="video-share-with-box col-xs-6 col-sm-6 col-md-12 col-lg-12">
                           <a href="#"><img class="page-icon" src="<?php echo get_template_directory_uri()?>/images/instagram-icon.png" alt=""></a>
                           <p class="social-ask">- Thumbs Up</p>
                       </div> -->
                       
                       
                       
                   </div>

 
         
            
                <div class="clear"></div>

		
		</div>
		
		<?php
        	
        	
        	
	}
}
?>

    
               

    </div><!------------END Box---------->



    <!------------START Sidebar---------->

<div class="sidebar-box col-xs-12 col-sm-4 col-md-4 col-lg-4">

    <?php
    if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar_widget')):
        ?>

<?php endif; ?>
</div>



    <!------------END Sidebar---------->


    <div class="row">
         <a href="<?php echo get_home_url().'/?page_id=32'?>"><div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3">
                <h3 class="ask-button">ASK QUESTIONS</h3>
            </div></a>

    </div>






</div>
<!------------END Content---------->







</div><!------------END Wrapper----------> 

<?php include (TEMPLATEPATH . '/footer2.php'); ?>