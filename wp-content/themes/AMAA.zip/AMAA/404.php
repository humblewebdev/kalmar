<?php
/**
 * The template for displaying 404 pages (Not Found).
 *

 */

get_header(); ?>


<!------------START Content Masonry---------->

<div class="main-content col-xs-12 col-sm-12 col-md-12 col-lg-12">


    <!------------START Intro Content---------->



    <div class="box col-xs-12 col-sm-12 col-md-12 col-lg-12">

        <div class="fwpage-content">
				<h1 class="not-found-title"><?php _e( 'We were unable to find what you were looking for.', 'amaa' ); ?></h1>
                                <hr>

				<div class="not-found-content">
					<h2><?php _e( 'This is somewhat embarrassing, isn&rsquo;t it?', 'amaa' ); ?></h2>
					<p><?php _e( 'It looks like nothing was found at this location. Click a different tab in the menu above to find your way!', 'amaa' ); ?></p>

					<?php //get_search_form(); ?>
                                        
                                        
				</div><!-- .not-found-content -->
			

           
            
                <div class="clear"></div>


        </div><!------------END Page-content---------->

    </div><!------------END Box---------->





    <div class="row">
        <a href="#"><div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3">
                <h3 class="ask-button">ASK QUESTIONS</h3>
            </div></a>

    </div>






</div>
<!------------END Content---------->







</div><!------------END Wrapper----------> 

<?php include (TEMPLATEPATH . '/footer2.php'); ?>