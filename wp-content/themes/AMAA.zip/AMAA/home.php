<?php
/*
  Template Name: Blog Page Template
 */
get_header(); ?>


<!-      START Content Masonry        ->

<div class="main-content col-xs-12 col-sm-12 col-md-12 col-lg-12">
    
    <div class="filters">
        <ul class="filters-ul col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <?php  
        
        $categories = get_categories();
        foreach($categories as $category){
        	echo '<li class="col-xs-12 col-sm-3 col-md-3 col-lg-3"><a href="'. get_category_link( $category->term_id ).'">'.$category->name.'</a></li>';
        }
        
?>
        </ul>
        <br>
        <br>
        
    </div>



 <!-      START Featured Blog      ->

    <?php
    /*
      Create Featured Blog Post
     */
    $args = array(
        'posts_per_page' => 10,
        'offset' => 0,
        'category' => '',
        'orderby' => 'post_date',
        'order' => 'DESC',
        'include' => '',
        'exclude' => '',
        'meta_key' => '',
        'meta_value' => '',
        'post_type' => 'post',
        'post_mime_type' => '',
        'post_parent' => '',
        'post_status' => 'publish',
        'suppress_filters' => true);

    $posts_array = get_posts($args);
    if (!empty($posts_array)) {
        $post_template[] = array();
        foreach ($posts_array as $single_post) {
            $categories = get_the_category($single_post->ID);
            $category_links_array = array();
            $category_text_array = array();
            foreach ($categories as $category) {
                $category_text_array[] = $category->cat_name;
                $category_links_array[] = $category->term_id;
            }

            $category_text_string = implode(', ', $category_text_array);

            if (has_post_thumbnail($single_post->ID)) {
                $post_image = wp_get_attachment_image_src(get_post_thumbnail_id($single_post->ID), 'single_post_thumbnail');
            } else {
                $post_image = array(get_template_directory_uri().'/images/resiliency.jpg');
            }


            if (in_array('Featured', $category_text_array)) {
                if(strlen($single_post->post_content) > 225){
                   $post_content = substr($single_post->post_content,0, 225).'...'; 
                }else {
                    $post_content = $single_post->post_content;
                }
                
                if(strlen($single_post->post_title) > 40){
                    $post_title = substr($single_post->post_title,0, 40).'...';
                }else {
                    $post_title = $single_post->post_title;
                }
                
                $post_template['Featured'] = "<div class='box col-xs-12 col-sm-6 col-md-6 col-lg-6'>
	<div class='featured-blog'>
        <p class='featured-category'>" . strtoupper($category_text_string) . "</p>
		<!-- Gets Title of the post-->
        	<h2>" . $post_title . "</h2>
            <div class='featured-image'>
            	<img src='" . $post_image[0] . "' alt=''>
            </div>
			<!-- Gets Content of the post-->
			" . $post_content . "
            <a href=" . $single_post->guid . "><p class='read-more'>READ MORE</p></a>
		<div class='clear'></div>
    </div>                
</div>";
            } else if(!in_array('Featured', $category_text_array)) {
                
                if(strlen($single_post->post_content) > 125){
                   $post_content = substr($single_post->post_content,0, 125).'...'; 
                }else {
                    $post_content = $single_post->post_content;
                }
                
                if(strlen($single_post->post_title) > 20){
                    $post_title = substr($single_post->post_title,0, 20).'...';
                }else {
                    $post_title = $single_post->post_title;
                }
                
                
                $post_template[] = "<div class='box col-xs-12 col-sm-3 col-md-3 col-lg-3'>
	<div class='blog-post'>
        <p class='category'>" . strtoupper($category_text_string) . "</p>
		<!-- Gets Title of the post-->
        	<h2>" . $post_title . "</h2>
            <div class='blog-post-image'>
            	<img src='" . $post_image[0] . "' alt='...'>
            </div>
			<!-- Gets Content of the post-->
			" . $post_content . "
            <a href=" . $single_post->guid . "><p class='read-more'>READ MORE</p></a>
		<div class='clear'></div>
    </div>                
</div>";
            }
            
        }
        echo $post_template['Featured'];
        foreach($post_template as $post_key => $post_value){
            if($post_key != 'Featured'){
                echo $post_value;
            }
        }
    }
    ?>


    <!-      END Blog Posts      ->


    <div class="row">
        <a href="<?php echo get_home_url().'/?page_id=32'?>"><div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3">
                <h3 class="ask-button">ASK QUESTIONS</h3>
            </div></a>

    </div>



</div>
<!-      END Content      ->





</div><!-      END Wrapper      -> 
<script>
    $(document).ready(function(){
        $(".box").click(function(){
            window.location=$(this).find("a").attr("href"); 
            return false;
        });
    });
</script>
<?php get_footer(); ?>