<?php
/**
 * The template for displaying Search Results pages.
 *

 */

get_header(); ?>


<!------------START Content Masonry---------->

<div class="main-content col-xs-12 col-sm-12 col-md-12 col-lg-12">


    <!------------START Intro Content---------->



    <div class="box col-xs-12 col-sm-8 col-md-8 col-lg-8">

        <div class="page-content">

		<?php if ( have_posts() ) : ?>

			
				<h1 class="search-title"><?php printf( __( 'Search Results for: %s', 'amaa' ), get_search_query() ); ?></h1>
			
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', get_post_format() ); ?>
			<?php endwhile; ?>

			

		<?php else : ?>
			<?php get_template_part( 'content', 'none' ); ?>
		<?php endif; ?>


        
        
      



           
            
                <div class="clear"></div>


        </div><!------------END Page-content---------->

    </div><!------------END Box---------->



    <!------------START Sidebar---------->

<div class="sidebar-box col-xs-12 col-sm-4 col-md-4 col-lg-4">

    <?php
    if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar_widget')):
        ?>

<?php endif; ?>
</div>



    <!------------END Sidebar---------->


    <div class="row">
        <a href="#"><div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3">
                <h3 class="ask-button">ASK QUESTIONS</h3>
            </div></a>

    </div>






</div>
<!------------END Content---------->







</div><!------------END Wrapper----------> 

<?php include (TEMPLATEPATH . '/footer2.php'); ?>