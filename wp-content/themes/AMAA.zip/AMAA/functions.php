<?php
//Register a nav bar
function register_my_menu() {
	register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_my_menu' );


// Regsiter a widget area
if (function_exists('register_sidebar')) {
	register_sidebar(array(
	'name' => 'footer_widget',
	'id'   => 'footer_widget',
	'description'   => '',
	'before_widget' => '<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3"><div class="footer-widget">',
	'after_widget'  => '</div></div>',
	'before_title'  => '<h4>',	
	'after_title'   => '</h4>'
			));
}
// Regsiter a widget area
if (function_exists('register_sidebar')) {
	register_sidebar(array(
	'name' => 'sidebar_widget',
	'id'   => 'sidebar_widget',
	'description'   => '',
	'before_widget' => '<div class="sidebar-widget">',
	'after_widget'  => '</div>',
	'before_title'  => '<h4 class="sidebar-titles">',	
	'after_title'   => '</h4>'
			));
}

add_theme_support( 'post-thumbnails' );

// Switches default core markup for search form, comment form, and comments
	// to output valid HTML5.
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );


if ( ! function_exists( 'amaa_paging_nav' ) ) :
/**
 * Displays navigation to next/previous set of posts when applicable.

 */
function amaa_paging_nav() {
	global $wp_query;

	// Don't print empty markup if there's only one page.
	if ( $wp_query->max_num_pages < 2 )
		return;
	?>
	<nav class="navigation paging-navigation" role="navigation">
		
		<div class="nav-links">

			<?php if ( get_next_posts_link() ) : ?>
			<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'amaa' ) ); ?></div>
			<?php endif; ?>

			<?php if ( get_previous_posts_link() ) : ?>
			<div class="nav-next"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'amaa' ) ); ?></div>
			<?php endif; ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'amaa_post_nav' ) ) :
/**
 * Displays navigation to next/previous post when applicable.
*
* @since Twenty Thirteen 1.0
*
* @return void
*/
function amaa_post_nav() {
	global $post;

	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous )
		return;
	?>
	<nav class="navigation post-navigation" role="navigation">
		
		<div class="next-page col-xs-12 col-sm-3 col-md-6 col-lg-6">
                    

			<div class="prev"><?php previous_post_link( '%link', _x( '<span class="meta-nav"><h4>PREV < </span>  | &nbsp; </h4>', 'Previous post link', 'amaa' ) ); ?></div>
			<div class="next"><?php next_post_link( '%link', _x( '<span class="meta-nav"><h4>NEXT > </h4></span>', 'Next post link', 'amaa' ) ); ?></div>
                   
		</div><!-- .next-page -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'amaa_entry_meta' ) ) :
/**
 * Prints HTML with meta information for current post: categories, tags, permalink, author, and date.
 *
 * Create your own twentythirteen_entry_meta() to override in a child theme.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function amaa_entry_meta() {
	

	// Translators: used between list items, there is a space after the comma.
	$categories_list = get_the_category_list( __( ', ', 'amaa' ) );
	if ( $categories_list ) {
		echo '<span class="categories-links">' . $categories_list . '</span>';
	}

	// Translators: used between list items, there is a space after the comma.
	$tag_list = get_the_tag_list( '', __( ', ', 'amaa' ) );
	if ( $tag_list ) {
		echo '<span class="tags-links">' . $tag_list . '</span>';
	}

	
}
endif;

add_action( 'wp_print_styles', 'my_styles' );

function my_styles(){
    wp_deregister_style( 'wp-members' );
}


// Register style sheet.
function theme_name_scripts() {
        
	
	wp_enqueue_style( 'jquery_ui_css', 'http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css' );
	wp_enqueue_style( 'custom_bootstrap_css', get_template_directory_uri() . '/css/bootstrap.min.css' );
        wp_enqueue_style( 'base_css', get_stylesheet_uri() );
	wp_enqueue_script( 'jquery', 'http://code.jquery.com/jquery-1.9.1.js' );
        wp_enqueue_script( 'jquery_ui', 'http://code.jquery.com/ui/1.10.3/jquery-ui.js' );
        wp_enqueue_script( 'custom_bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js' );
}

add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );


function load_google_fonts() {
	wp_register_style('googleFontsChauPhilomeneOne','http://fonts.googleapis.com/css?family=Chau+Philomene+One');
        wp_enqueue_style( 'googleFontsChauPhilomeneOne'); 

        wp_register_style('googleFontsOpenSans','http://fonts.googleapis.com/css?family=Open+Sans:400,600,700');
        wp_enqueue_style( 'googleFontsOpenSans');

}
add_action('wp_print_styles', 'load_google_fonts');




add_action( 'admin_menu', 'my_create_post_meta_box' );
add_action( 'save_post', 'my_save_post_meta_box', 10, 2 );

function my_create_post_meta_box() {
	add_meta_box( 'my-meta-box', 'Youtube-Video', 'my_post_meta_box', 'post', 'normal', 'high' );
}

function my_post_meta_box( $object, $box ) { ?>
	<p>
		<label for="youtube-video">Embed Youtube Video  (Set the width="798" height="588")</label>
		<br />
		<textarea name="youtube-video" id="youtube-video" cols="60" rows="4" tabindex="30" style="width: 97%;"><?php echo esc_html( get_post_meta( $object->ID, 'Youtube-Video', true ), 1 ); ?></textarea>
		<input type="hidden" name="my_meta_box_nonce" value="<?php echo wp_create_nonce( plugin_basename( __FILE__ ) ); ?>" />
	</p>
<?php }

function my_save_post_meta_box( $post_id, $post ) {

	if ( !wp_verify_nonce( $_POST['my_meta_box_nonce'], plugin_basename( __FILE__ ) ) )
		return $post_id;

	if ( !current_user_can( 'edit_post', $post_id ) )
		return $post_id;

	$meta_value = get_post_meta( $post_id, 'Youtube-Video', true );
	$new_meta_value = stripslashes( $_POST['youtube-video'] );

	if ( $new_meta_value && '' == $meta_value )
		add_post_meta( $post_id, 'Youtube-Video', $new_meta_value, true );

	elseif ( $new_meta_value != $meta_value )
		update_post_meta( $post_id, 'Youtube-Video', $new_meta_value );

	elseif ( '' == $new_meta_value && $meta_value )
		delete_post_meta( $post_id, 'Youtube-Video', $meta_value );
}



 